Codec: IDT 92HD93BXX
Address: 0
Vendor Id: 0x111d76df
Subsystem Id: 0x1028053f
Revision Id: 0x100203


EN: Use Layout 3 in the Patch HDEF your DSDT.

PT_BR: Usar layout 3 no patch HDEF do seu DSDT.

@Kext Patched by Mirone - www.olarila.com - www.insanelymac.com - www.hackintoshosx.com

Method (_DSM, 4, NotSerialized)
                {
                    Store (Package (0x0c)
                    {                        
                        "built-in", 
                        Buffer (One)
                        {
                            0x00
                        }, 
                        "layout-id", 
                        Buffer (0x04)
                        {
                            0x03, 0x00, 0x00, 0x00
                        }, 
                       "PinConfigurations", 
                       Buffer (0x00)
                       {
                           0x00
                       }
                    }, Local0)
                    DTGP (Arg0, Arg1, Arg2, Arg3, RefOf (Local0))
                    Return (Local0)
                }